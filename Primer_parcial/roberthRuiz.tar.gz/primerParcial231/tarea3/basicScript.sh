#!/bin/bash
echo "Ingrese su nombre:"
read nombre
echo "Hola,un gusto en conocerte $nombre"
tree
2 directories, 4 files
finalizado
